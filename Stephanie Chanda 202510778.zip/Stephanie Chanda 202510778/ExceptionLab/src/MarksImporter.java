import java.io.*;
import java.util.*;
import java.util.logging.*;

/**
 * ICT261 | Unit 4 | Exception Handling and Error Management
 * ExceptionLab - MarksImporter
 *
 * Imports student marks from a text file (one record per line: ID, mark).
 * Recovery strategy chosen: SKIP the bad record, report it clearly,
 * and CONTINUE with the remaining records.
 * (Set -Dstop.on.error=true to make the first bad record stop the import.)
 */

/** Custom UNCHECKED exception: a student number appeared more than once. */
class DuplicateStudentException extends RuntimeException {
    private static final long serialVersionUID = 1L;
    private final String studentId;

    public DuplicateStudentException(String studentId) {
        super("Duplicate student number: " + studentId);
        this.studentId = studentId;
    }

    public String getStudentId() {
        return studentId;
    }
}

public class MarksImporter {

    private static final Logger LOGGER =
            Logger.getLogger(MarksImporter.class.getName());

    /** Recovery strategy switch: false = skip bad record (default), true = stop. */
    private static final boolean STOP_ON_ERROR = Boolean.getBoolean("stop.on.error");

    // ------------------------------------------------------------------
    // Importer
    // ------------------------------------------------------------------
    static void importMarks(String filename) throws IOException {
        Set<String> seen = new HashSet<>();
        int accepted = 0;
        int skipped = 0;
        int lineNo = 0;

        // try-with-resources: the BufferedReader (and the FileReader inside it)
        // implements AutoCloseable, so Java calls br.close() automatically when
        // the block ends - whether it finishes normally OR an exception is thrown.
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                lineNo++;
                if (line.trim().isEmpty()) {
                    continue;                       // ignore blank lines
                }
                try {
                    String[] parts = line.split(",");

                    // TODO 1: check there are exactly 2 fields
                    if (parts.length != 2) {
                        throw new IllegalArgumentException(
                                "expected 2 fields (ID, mark) but found " + parts.length);
                    }

                    // TODO 2: parse mark and validate range 0..100
                    String id = parts[0].trim();
                    if (id.isEmpty()) {
                        throw new IllegalArgumentException("student number is empty");
                    }
                    int mark;
                    try {
                        mark = Integer.parseInt(parts[1].trim());
                    } catch (NumberFormatException nfe) {
                        // wrap with a clearer message and keep the original as the cause
                        throw new IllegalArgumentException(
                                "mark '" + parts[1].trim() + "' is not a whole number", nfe);
                    }
                    if (mark < 0 || mark > 100) {
                        throw new IllegalArgumentException(
                                "mark " + mark + " is outside the valid range 0..100");
                    }

                    // TODO 3: detect repeated student ID using seen
                    if (!seen.add(id)) {            // add() returns false if already present
                        throw new DuplicateStudentException(id);
                    }

                    // TODO 4: display accepted record
                    System.out.println("Accepted: " + id + " -> " + mark);
                    accepted++;

                } catch (DuplicateStudentException | IllegalArgumentException e) {
                    // Friendly message for the user, technical detail for the log.
                    System.out.println("Line " + lineNo + " skipped: " + friendly(e));
                    LOGGER.log(Level.WARNING, "Line " + lineNo + " rejected ["
                            + e.getClass().getName() + "] " + e.getMessage()
                            + (e.getCause() != null ? " | cause: " + e.getCause() : ""), e);
                    skipped++;
                    if (STOP_ON_ERROR) {
                        throw e;                    // let main() handle it and stop
                    }
                }
            }
        }
        System.out.println("Import summary: " + accepted + " accepted, "
                + skipped + " skipped.");
    }

    /** Turns a technical exception into a short message an ordinary user can act on. */
    private static String friendly(RuntimeException e) {
        if (e instanceof DuplicateStudentException) {
            return "student number " + ((DuplicateStudentException) e).getStudentId()
                    + " appears more than once.";
        }
        return "invalid data - " + e.getMessage() + ".";
    }

    // ------------------------------------------------------------------
    // Logging: technical details go to import.log, NOT to the console
    // ------------------------------------------------------------------
    private static void setupLogging() {
        System.setProperty("java.util.logging.SimpleFormatter.format",
                "%1$tF %1$tT %4$s %5$s%6$s%n");
        try {
            LOGGER.setUseParentHandlers(false);     // keep stack traces off the console
            FileHandler fh = new FileHandler("import.log", true);
            fh.setFormatter(new SimpleFormatter());
            LOGGER.addHandler(fh);
        } catch (IOException | SecurityException ex) {
            System.out.println("Note: technical log could not be created.");
        }
    }

    // ------------------------------------------------------------------
    // main
    // ------------------------------------------------------------------
    public static void main(String[] args) {
        String filename = args.length > 0 ? args[0] : "marks.txt";
        setupLogging();

        try {
            importMarks(filename);
        } catch (FileNotFoundException e) {          // must come BEFORE IOException
            System.out.println("Marks file not found; check the file name.");
            LOGGER.log(Level.SEVERE, "File not found: " + filename, e);
        } catch (IOException e) {                    // any other I/O problem
            System.out.println("The marks file could not be read. Please try again.");
            LOGGER.log(Level.SEVERE, "I/O error while reading " + filename, e);
        } catch (DuplicateStudentException e) {      // reached only when STOP_ON_ERROR
            System.out.println("Import stopped: " + friendly(e));
            LOGGER.log(Level.SEVERE, "Import stopped on duplicate", e);
        } catch (IllegalArgumentException e) {       // reached only when STOP_ON_ERROR
            System.out.println("Import stopped: " + friendly(e));
            LOGGER.log(Level.SEVERE, "Import stopped on invalid data", e);
        } finally {
            System.out.println("Import attempt finished");   // always runs
        }
    }
}
