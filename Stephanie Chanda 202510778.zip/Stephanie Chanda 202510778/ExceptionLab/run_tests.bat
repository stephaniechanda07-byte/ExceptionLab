@echo off
REM Compiles MarksImporter and runs the five lab tests (T1-T5). Needs a JDK on the PATH.
cd /d "%~dp0"
if not exist out mkdir out
if not exist output mkdir output
javac -d out src\MarksImporter.java || exit /b 1
if exist import.log del import.log
java -cp out MarksImporter > output\full_run_output.txt
type output\full_run_output.txt
for %%T in (T1 T2 T3 T4 T5) do (
  pushd tests\%%T
  if exist import.log del import.log
  if "%%T"=="T5" (set ARG=absent.txt) else (set ARG=marks.txt)
  call java -cp ..\..\out MarksImporter %%ARG%% > ..\..\output\%%T_output.txt
  type ..\..\output\%%T_output.txt
  popd
)
