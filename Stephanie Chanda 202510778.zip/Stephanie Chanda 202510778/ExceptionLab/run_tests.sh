#!/bin/sh
# Compiles MarksImporter and runs the five lab tests (T1-T5).
# Needs a JDK (javac + java) on the PATH.
cd "$(dirname "$0")"
mkdir -p out output
javac -d out src/MarksImporter.java || exit 1

echo "== Full run with the supplied marks.txt =="
rm -f import.log
java -cp out MarksImporter | tee output/full_run_output.txt
cp import.log output/full_run_import.log

echo "== Full run, STOP strategy (-Dstop.on.error=true) =="
rm -f import.log
java -Dstop.on.error=true -cp out MarksImporter | tee output/full_run_STOP_output.txt
cp import.log output/full_run_STOP_import.log
rm -f import.log

for t in T1 T2 T3 T4 T5; do
  echo "== $t =="
  ( cd tests/$t && rm -f import.log
    if [ "$t" = "T5" ]; then ARG=absent.txt; else ARG=marks.txt; fi
    java -cp ../../out MarksImporter $ARG | tee ../../output/${t}_output.txt
    cp import.log ../../output/${t}_import.log 2>/dev/null
    rm -f import.log )
done
