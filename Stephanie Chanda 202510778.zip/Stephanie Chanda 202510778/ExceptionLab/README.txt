ICT261 | Unit 4 | Java Exception Handling Lab  -  ExceptionLab
=========================================================

Contents
  src/MarksImporter.java    Solution (includes the custom DuplicateStudentException)
  marks.txt                 The four records given in the lab sheet
  tests/T1 .. T5            Input file used for each test case
  output/                   Console output (Tn_output.txt) and technical log (Tn_import.log)
  run_tests.sh / .bat       Compile and run all tests (needs a JDK 11 or later)

Run by hand
  javac -d out src/MarksImporter.java
  java -cp out MarksImporter                 (reads marks.txt)
  java -cp out MarksImporter absent.txt      (T5: file-not-found case)
  java -Dstop.on.error=true -cp out MarksImporter   (STOP strategy instead of SKIP)

IDE (IntelliJ / Eclipse / NetBeans)
  Create a Java project named ExceptionLab, copy src/MarksImporter.java into it and
  place marks.txt in the project root (the working directory). Run MarksImporter.

Recovery strategy: an invalid record is SKIPPED, reported on the console in plain
language, and logged with full technical detail to import.log.
